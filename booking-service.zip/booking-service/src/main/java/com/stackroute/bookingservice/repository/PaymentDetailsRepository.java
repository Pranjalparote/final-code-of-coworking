//package com.stackroute.bookingservice.repository;
//
//import PaymentDetails;
//import org.springframework.data.mongodb.repository.MongoRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface PaymentDetailsRepository extends MongoRepository<PaymentDetails, String> {
//    PaymentDetails save(PaymentDetails paymentDetails);
//}
